package com.example.guessthatnumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Settings extends AppCompatActivity {
    private Button openThemesButton;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        openThemesButton = (Button) findViewById(R.id.Themes);
        openThemesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openThemes();
            }
        });
    }
    public void openThemes() {
        Intent intent = new Intent(this, Themes.class);
        startActivity(intent);
    }
}