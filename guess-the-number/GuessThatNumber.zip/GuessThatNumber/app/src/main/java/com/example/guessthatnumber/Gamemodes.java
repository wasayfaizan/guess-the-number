package com.example.guessthatnumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Gamemodes extends AppCompatActivity {
    private Button pickGameModeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gamemodes);
        pickGameModeButton = (Button) findViewById(R.id.playGameMode1);
        pickGameModeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openPickGameMode();
            }
        });
    }
    public void openPickGameMode() {
        Intent intent = new Intent(this, PlayGame.class);
        startActivity(intent);
    }
}